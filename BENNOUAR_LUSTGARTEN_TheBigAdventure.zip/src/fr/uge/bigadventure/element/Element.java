package fr.uge.bigadventure.element;

public sealed interface Element permits Entity, Item {

}
