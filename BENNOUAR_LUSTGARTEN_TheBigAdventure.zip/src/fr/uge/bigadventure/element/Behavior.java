package fr.uge.bigadventure.element;

public enum Behavior {
	SHY, STROLL, AGRESSIVE
}
