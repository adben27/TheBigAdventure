package fr.uge.bigadventure.element;

public enum Kind {
	FRIEND, ENEMY, ITEM, OBSTACLE
}
