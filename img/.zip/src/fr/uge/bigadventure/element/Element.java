package fr.uge.bigadventure.element;

public interface Element {
	
}
