package fr.uge.bigadventure;

public enum Direction {
	NORTH,
	SOUTH,
	EAST,
	WEST,
}
